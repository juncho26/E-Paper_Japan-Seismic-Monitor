"""
main.py — persistent process for the Pi, hardened for years of unattended
operation as well as tuned for emergency responsiveness.

Responsiveness (unchanged from before):
Primary path is a live WebSocket connection to P2PQuake
(wss://api.p2pquake.net/v2/ws) — a new event triggers a partial refresh
within about a second of JMA issuing it. A slow polling fallback (60s)
runs alongside it purely as a safety net. Every event-triggered push is a
partial refresh; full refreshes live on their own independent clock so a
ghosting cleanup can never delay an emergency update.

What's new here is everything to do with running this for years without
a human ever needing to intervene:

- Exponential backoff (capped) on every network failure, instead of
  hammering the API or spinning tight on a dead connection.
- A systemd watchdog heartbeat, so a genuine hang (not a crash — a
  deadlock, a stuck SPI call) still gets caught and restarted, which a
  plain crash-only Restart= policy would miss entirely.
- Every hardware call (SPI/GPIO through the Waveshare driver) is wrapped
  so a single flaky transaction logs and retries rather than taking the
  whole process down.
- Interval timers use time.monotonic(), not time.time(), so an NTP clock
  correction after boot can't cause a spurious immediate (or indefinitely
  delayed) full refresh.
- A real startup retry loop: the first fetch keeps trying with backoff
  instead of giving up after one attempt and leaving the panel blank.
"""

import json
import logging
import os
import socket
import threading
import time
import traceback

import websocket  # pip install websocket-client

import render

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("seismic-epaper")

WS_URL = "wss://api.p2pquake.net/v2/ws"
FALLBACK_POLL_SECONDS = 60                    # safety net only — not the primary path
MAINTENANCE_FULL_REFRESH_SECONDS = 6 * 3600   # ghosting cleanup cadence
WATCHDOG_MARGIN = 2.5                         # ping at WatchdogSec / this margin

BACKOFF_BASE = 2.0
BACKOFF_CAP = 120.0

state = {
    "epd": None,
    "last_event_id": None,
    "last_frame": None,
    "last_full_refresh": 0.0,
    "lock": threading.Lock(),
}


# ---------- systemd integration (watchdog + ready notification) ----------
# Implemented directly over the notify socket rather than pulling in the
# sdnotify package — it's a five-line protocol and one fewer dependency to
# keep updated over five years.

def _sd_notify(message):
    addr = os.environ.get("NOTIFY_SOCKET")
    if not addr:
        return  # not running under systemd (e.g. manual `python3 main.py`) — no-op
    if addr.startswith("@"):
        addr = "\0" + addr[1:]
    try:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_DGRAM)
        sock.connect(addr)
        sock.sendall(message.encode())
        sock.close()
    except OSError as e:
        log.warning("sd_notify failed: %s", e)


def run_watchdog_pings():
    watchdog_usec = os.environ.get("WATCHDOG_USEC")
    if not watchdog_usec:
        return  # WatchdogSec not configured in the unit — nothing to do
    interval = float(watchdog_usec) / 1_000_000 / WATCHDOG_MARGIN
    while True:
        time.sleep(interval)
        # Only ping if the fallback-poll thread has proven itself alive
        # recently — a real hang in that thread should NOT be pinged over.
        if time.monotonic() - state.get("last_poll_alive", 0) < FALLBACK_POLL_SECONDS * 3:
            _sd_notify("WATCHDOG=1")
        else:
            log.warning("fallback poll thread looks stalled — withholding watchdog ping")


# ---------- hardware access, wrapped for resilience ----------

def get_epd():
    from waveshare_epd import epd4in2_V2
    epd = epd4in2_V2.EPD()
    epd.init()
    epd.Clear()
    return epd


def safe_hw_call(fn, *args, retries=2, **kwargs):
    """Every SPI/GPIO transaction goes through here. A single flaky
    transaction (a marginal wire, a brief power sag) shouldn't take the
    whole process down — log it, back off briefly, retry a couple of
    times, and only propagate if it's genuinely stuck."""
    last_exc = None
    for attempt in range(retries + 1):
        try:
            return fn(*args, **kwargs)
        except Exception as e:
            last_exc = e
            log.warning("hardware call %s failed (attempt %d/%d): %s",
                        getattr(fn, "__name__", fn), attempt + 1, retries + 1, e)
            time.sleep(1.5 * (attempt + 1))
    raise last_exc


def reinit_display():
    """Called when the display seems stuck — a fresh init sometimes clears
    a wedged SPI/GPIO state without needing a full process restart."""
    log.warning("reinitialising display")
    state["epd"] = safe_hw_call(get_epd)


# ---------- event handling ----------

def push_partial(events, reason):
    with state["lock"]:
        frame = render.build_frame(events)
        state["last_frame"] = frame
        try:
            buf = safe_hw_call(state["epd"].getbuffer, frame)
            log.info("partial refresh (%s)", reason)
            safe_hw_call(state["epd"].display_Partial, buf)
        except Exception:
            log.error("partial refresh failed after retries, reinitialising:\n%s",
                       traceback.format_exc())
            try:
                reinit_display()
            except Exception:
                log.error("reinit also failed — will try again on the next event")


def handle_new_events(events, reason):
    if not events:
        return
    latest_id = events[0].get("id")
    if latest_id == state["last_event_id"]:
        return
    state["last_event_id"] = latest_id
    push_partial(events, reason)


# ---------- WebSocket (primary, low-latency path) ----------

def on_ws_message(ws, message):
    state["ws_backoff"] = BACKOFF_BASE  # any message proves the connection is healthy
    try:
        data = json.loads(message)
    except ValueError:
        return
    if data.get("code") != 551:
        return  # this renderer only handles the detailed-intensity report type
    try:
        events = render.fetch_events()  # re-fetch so the "recent" list stays consistent
    except Exception as e:
        log.warning("history refetch after ws push failed: %s", e)
        events = [data]
    handle_new_events(events, "websocket")


def on_ws_error(ws, error):
    log.warning("websocket error: %s", error)


def on_ws_close(ws, *_):
    log.info("websocket closed — reconnecting")


def run_websocket_forever():
    state["ws_backoff"] = BACKOFF_BASE
    while True:
        try:
            ws = websocket.WebSocketApp(
                WS_URL,
                on_message=on_ws_message,
                on_error=on_ws_error,
                on_close=on_ws_close,
            )
            # p2pquake force-closes idle sockets roughly every 10 minutes —
            # expected, and just lands us back here, not an error worth
            # backing off for (on_ws_message already reset the backoff).
            ws.run_forever(ping_interval=30, ping_timeout=10)
        except Exception:
            log.warning("websocket loop crashed:\n%s", traceback.format_exc())
        backoff = state.get("ws_backoff", BACKOFF_BASE)
        time.sleep(backoff)
        state["ws_backoff"] = min(backoff * 2, BACKOFF_CAP)


# ---------- fallback poll (redundancy, and the watchdog's proof-of-life) ----------

def run_fallback_poll():
    backoff = BACKOFF_BASE
    while True:
        time.sleep(FALLBACK_POLL_SECONDS)
        try:
            events = render.fetch_events()
            handle_new_events(events, "fallback poll")
            backoff = BACKOFF_BASE
        except Exception as e:
            log.warning("fallback poll failed (backing off %.0fs): %s", backoff, e)
            time.sleep(backoff)
            backoff = min(backoff * 2, BACKOFF_CAP)
        finally:
            # recorded even on failure — a live-but-erroring loop still
            # proves the process isn't deadlocked, which is what the
            # watchdog actually needs to know
            state["last_poll_alive"] = time.monotonic()


# ---------- maintenance (ghosting cleanup, fully decoupled from events) ----------

def run_maintenance_refresh():
    while True:
        time.sleep(60)
        if time.monotonic() - state["last_full_refresh"] < MAINTENANCE_FULL_REFRESH_SECONDS:
            continue
        if state["last_frame"] is None:
            continue
        with state["lock"]:
            try:
                log.info("maintenance full refresh")
                safe_hw_call(state["epd"].init)
                safe_hw_call(state["epd"].display, safe_hw_call(state["epd"].getbuffer, state["last_frame"]))
                state["last_full_refresh"] = time.monotonic()
            except Exception:
                log.error("maintenance refresh failed:\n%s", traceback.format_exc())


# ---------- startup ----------

def fetch_with_retry():
    """The very first fetch keeps trying with backoff instead of giving up
    after one attempt — a slow DHCP lease or not-yet-up WiFi at boot
    shouldn't leave the panel blank until the next lucky event."""
    backoff = BACKOFF_BASE
    while True:
        try:
            return render.fetch_events()
        except Exception as e:
            log.warning("startup fetch failed (retrying in %.0fs): %s", backoff, e)
            time.sleep(backoff)
            backoff = min(backoff * 2, BACKOFF_CAP)


def main():
    state["epd"] = safe_hw_call(get_epd, retries=5)
    state["last_full_refresh"] = time.monotonic()
    state["last_poll_alive"] = time.monotonic()

    events = fetch_with_retry()
    frame = render.build_frame(events)
    state["last_frame"] = frame
    safe_hw_call(state["epd"].display, safe_hw_call(state["epd"].getbuffer, frame), retries=5)
    if events:
        state["last_event_id"] = events[0].get("id")

    threading.Thread(target=run_fallback_poll, daemon=True).start()
    threading.Thread(target=run_maintenance_refresh, daemon=True).start()
    threading.Thread(target=run_watchdog_pings, daemon=True).start()

    _sd_notify("READY=1")
    log.info("startup complete")

    try:
        run_websocket_forever()
    except KeyboardInterrupt:
        pass
    finally:
        log.info("sleeping display")
        try:
            state["epd"].sleep()
        except Exception:
            pass


if __name__ == "__main__":
    try:
        main()
    except Exception:
        traceback.print_exc()
        raise SystemExit(1)
