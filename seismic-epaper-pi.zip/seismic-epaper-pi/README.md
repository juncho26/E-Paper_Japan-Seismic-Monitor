# Japan seismic monitor — Waveshare 4.2" V2 e-paper on a Pi Zero WH

This renders the same idea as the browser artifact — prefecture outlines,
station activity, the latest JMA-relayed event — but as a native 400x300
1-bit image drawn with Pillow, no browser involved. E-paper panels take a
raw pixel buffer over SPI; there's no HTML/CSS/JS anywhere in this pipeline,
and running a browser engine on a Pi Zero's single-core ARMv6 chip to get
one isn't practical.

## What's here

- `render.py` — builds one frame. Also runnable standalone (`python3
  render.py`) to produce `preview.png` on any machine, so you can check the
  layout before touching hardware.
- `main.py` — the long-running process for the Pi: a live WebSocket
  connection for near-instant updates, a slow polling fallback for
  redundancy, and the reliability hardening described further down
  (watchdog, backoff, hardware-fault tolerance) for years of unattended
  operation.
- `data/` — prefecture boundaries, the station list, and the ocean-safe
  label anchor points, all carried over from the web version.
- `fonts/NotoSansJP-Bold.ttf` — an open-license (OFL) Japanese font,
  needed because region names come back from JMA in Japanese and the
  default Pillow font has no CJK glyphs. This is a custom-built subset:
  pre-instanced to a static bold weight and cut down to JIS X 0208 levels
  1+2 (~6,600 glyphs — covers essentially any real Japanese place name)
  instead of shipping the full ~9.5MB variable font with every CJK
  ideograph Unicode defines. See "Performance on a Pi Zero" below for why.
- `seismic-epaper.service` — systemd unit to run it persistently.

## What changed from the browser version, and why

- **No animation.** E-paper does a visible flash on a full refresh and
  can't show motion, so the P-wave ripple became a set of static
  concentric rings centered on the epicenter (one ring per shindo point,
  sized to how far the felt area actually reached) instead of an animated
  wavefront.
- **Only the active prefecture is labeled**, not all 46. At 400x300
  monochrome, that many leader lines would just be noise — worth reusing
  the ocean-anchor data, but only drawing it for whichever prefecture the
  latest event actually touched.
- **Stations are plain X markers, with no per-station circle.** Shindo
  intensity is shown once, at the epicenter (see above) — putting a scaled
  circle at every affected station as well turned into visual clutter for
  no added information, since they're all reporting values from the same
  event anyway.

## Refresh design — tuned for "know about it immediately"

This isn't polling on a timer. `main.py` holds a live WebSocket connection
to P2PQuake (`wss://api.p2pquake.net/v2/ws`), so a new event triggers a
partial refresh within roughly a second of JMA issuing it — there's no
poll interval to wait through. A slow fallback poll (every 60s) runs
alongside it purely as a safety net, in case the socket dies silently;
it only acts if it finds an event the socket path genuinely missed.

Every event-triggered push is a **partial refresh** — fast, no visible
flash, nothing about a new earthquake ever waits on a ghosting cleanup.
Full refreshes are on their own independent clock (every 6 hours by
default, in `MAINTENANCE_FULL_REFRESH_SECONDS`) and only touch the panel
during otherwise-quiet time, redrawing whatever's already on screen —
they never compete with an urgent update for priority.

One real limitation of the V2 panel worth knowing: partial refresh alone,
run indefinitely, does accumulate some ghosting over time — that's a
property of the panel's waveform, not something software fully avoids.
The 6-hour maintenance refresh is a starting point, not a guarantee; if
you notice ghosting building up faster than that clears it, shorten
`MAINTENANCE_FULL_REFRESH_SECONDS`. Since maintenance refreshes are
decoupled from events, tightening that number never costs you responsiveness
during an actual earthquake.


## Setup

1. **Enable SPI** on the Pi: `sudo raspi-config` → Interface Options → SPI → enable, then reboot.
2. **Wire the panel** per Waveshare's 4.2" V2 wiki page for the standard pin mapping (VCC/GND/DIN/CLK/CS/DC/RST/BUSY).
3. **Get the driver.** `waveshare_epd` isn't on PyPI — clone Waveshare's own repo and copy the library folder in:
   ```bash
   git clone https://github.com/waveshareteam/e-Paper.git
   cp -r e-Paper/RaspberryPi_JetsonNano/python/lib/waveshare_epd /home/pi/seismic-epaper/
   ```
4. **Install dependencies:**
   ```bash
   cd /home/pi/seismic-epaper
   pip3 install -r requirements.txt
   ```
5. **Test rendering without touching the panel:**
   ```bash
   python3 render.py   # writes preview.png — open it and check the layout
   ```
6. **Test the real display once, manually**, before wiring up the service:
   ```bash
   python3 main.py
   ```
7. **Install as a service:**
   ```bash
   sudo cp seismic-epaper.service /etc/systemd/system/
   sudo systemctl daemon-reload
   sudo systemctl enable --now seismic-epaper
   ```
8. **Cap the journal size** (see "SD card and journal growth" below) —
   worth doing before you forget about it for the next five years.
9. **Confirm the watchdog is actually wired up:**
   ```bash
   systemctl show seismic-epaper -p WatchdogUSec -p NotifyAccess
   ```
   `WatchdogUSec` should show `3min 20s` (200s) and `NotifyAccess` should
   be `main`. If `WatchdogUSec` shows `0`, the unit file wasn't picked up
   correctly by `daemon-reload` — the pings in `main.py` are harmless
   no-ops either way, but you won't get the hang-detection benefit.

## Things worth checking on your setup

- I pulled the exact method names (`init`, `Clear`, `display`,
  `display_Partial`, `getbuffer`, `sleep`) straight from Waveshare's current
  `epd4in2_V2.py`, so `main.py` should match your driver as-is — but
  Waveshare does revise these libraries, so if `import waveshare_epd`
  fails or a method is missing, diff against the copy you cloned.
- If your panel is mounted in portrait rather than landscape, rotate the
  final image before `getbuffer()` (`frame.rotate(90, expand=True)`) rather
  than reworking the layout — simpler and keeps everything else unchanged.
- `data/prefectures.geojson` and `data/stations.json` are static; no need
  to refetch them. Only the p2pquake call in `render.fetch_events()` needs
  the Pi to be online.

## Going further

`main.py` only acts on code `551` (the detailed seismic-intensity report).
p2pquake's WebSocket feed also carries code `556`, JMA's Earthquake Early
Warning (緊急地震速報) — that arrives *before* the detailed report, while
the quake may still be shaking, and is the actual basis of Japan's
real-time alert system. If seconds matter to you, extending
`on_ws_message` to also render on `556` (even as a bare "M~x.x, shaking
now" banner before the fuller `551` report replaces it) would be the next
place to look — I kept this version scoped to what the renderer already
draws, but the WebSocket connection is already there to build on.

## Performance on a Pi Zero

The Zero WH's single ARM1176JZF-S core and slow SD card make a few things
worth doing that wouldn't matter on faster hardware:

- **Font: static and subset, not variable.** A variable font (the kind
  Google Fonts ships by default) has to interpolate glyph outlines from
  variation deltas every time it's instanced — real CPU work, repeated on
  every render if you're not careful. `fonts/NotoSansJP-Bold.ttf` here is
  pre-instanced to a fixed weight and subset to ~6,600 glyphs (JIS X 0208
  levels 1+2, covering essentially any real Japanese place name), down
  from ~9.5MB to ~2.5MB. If you ever need to rebuild it — a different
  weight, or broader coverage — the pipeline was:
  ```bash
  pip install fonttools
  python -m fontTools.varLib.instancer NotoSansJP-Variable.ttf wght=700 -o static.ttf
  python -m fontTools.subset static.ttf --text-file=charset.txt --output-file=NotoSansJP-Bold.ttf \
      --glyph-names --layout-features='*' --notdef-glyph --notdef-outline --recommended-glyphs
  ```
  where `charset.txt` is whatever characters you need covered.

- **Nothing reloads from disk on every frame.** `render.py` used to call
  `load_fonts()`, re-read `prefectures.geojson`, `stations.json`, and
  `labels.json`, and rebuild the map projection on every single call to
  `build_frame()`. Since `main.py` is a long-running process that calls
  `build_frame()` every time an event arrives, all of that got moved
  behind a module-level cache (`_cache` in `render.py`) — loaded once per
  process, not once per earthquake.

- **The static map layer is rendered once, not redrawn.** Prefecture
  outlines (a few thousand line segments from the geojson) and the
  station X markers never change between frames — only the ripple and
  labels do. `get_base_map()` renders that static layer once and hands
  back a `.copy()` (a cheap in-memory copy) for each frame instead of
  re-walking the geojson every time. On this machine that took render
  time from ~14ms cold to ~3ms warm; the relative win should hold even
  though the Zero's absolute numbers will be slower.

- **Pillow should install from a prebuilt wheel, not compile from
  source.** Raspberry Pi OS's `pip` is configured to use
  [piwheels.org](https://www.piwheels.org) by default, which publishes
  prebuilt wheels for armv6 (the Zero's architecture) — `pip3 install
  Pillow` should be quick. If it starts compiling from source instead
  (slow, and needs `libjpeg-dev`/`zlib1g-dev`), check that piwheels
  hasn't been overridden in your pip config.

## Built for years of unattended operation

This is meant to run for years without anyone touching it. That needed more
than performance tuning — here's everything that changed for reliability,
and why:

- **Exponential backoff, everywhere.** The WebSocket reconnect loop, the
  fallback poll, and the startup fetch all back off (capped at 120s)
  instead of retrying at a fixed interval. A fixed retry either hammers
  the API during a real outage or recovers slower than it needs to during
  a brief one — backoff does the right thing in both cases. The backoff
  resets to its base value the moment a connection actually succeeds.
- **A systemd watchdog, not just crash detection.** `Restart=on-failure`
  only catches the process dying — it does nothing if the process is
  still running but hung (a deadlock, a stuck SPI transaction). The unit
  now uses `Type=notify` with `WatchdogSec=200`; `main.py`'s fallback-poll
  thread pings the watchdog after every cycle (success or failure — a
  loop that's erroring out is still proving it isn't deadlocked). If
  those pings stop, systemd kills and restarts the process even though
  nothing "crashed."
- **`StartLimitIntervalSec=0` in the unit.** systemd's default behavior is
  to *stop* restarting a service after too many failures in a short
  window — reasonable for most services, wrong for something meant to
  outlive a bad week of hardware or network issues unattended. This
  disables that ceiling; combined with our own backoff, restarts can
  never happen faster than is sensible, but they also never permanently
  give up.
- **Every hardware call goes through `safe_hw_call()`.** A single flaky
  SPI transaction (a marginal connection, a brief brownout) now logs and
  retries a couple of times before it's treated as a real failure. If a
  push genuinely fails, the code re-initialises the display (`epd.init()`
  again) rather than crashing the process over what's often a transient,
  self-clearing fault.
- **`time.monotonic()` for every interval timer**, not `time.time()`. A
  Pi Zero has no battery-backed clock — after a power loss, the system
  clock is wrong until NTP corrects it, and a wall-clock jump could
  otherwise trigger a spurious immediate full refresh or silently delay
  one for hours. Monotonic time can't jump.
- **A real startup retry loop.** The first fetch, at boot, keeps retrying
  with backoff instead of giving up after one attempt — a Pi that's up
  before its WiFi has finished associating shouldn't leave the panel
  blank until the next lucky earthquake.

### SD card and journal growth

The single biggest long-term failure mode on a Pi Zero isn't the code —
it's the microSD card wearing out or filling up from years of logging.
This project doesn't write its own log files (everything goes to
`stdout`/`stderr`, captured by the systemd journal), but the journal
itself needs a cap or it'll grow for five years straight. Add this once:

```
sudo mkdir -p /etc/systemd/journald.conf.d
sudo nano /etc/systemd/journald.conf.d/seismic-epaper.conf
```

Put this in that file:

```
[Journal]
SystemMaxUse=50M
```

Then:

```
sudo systemctl restart systemd-journald
```

Also worth doing, if you haven't already: use a **high-endurance microSD
card** (rated for continuous writes, not a generic consumer card), and
power the Pi from a **stable, adequately-rated 5V supply** — brownouts
during an SD write are a common real-world cause of card corruption on
long-running Pi deployments, and are outside anything this code can fix.
