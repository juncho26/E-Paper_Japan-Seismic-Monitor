"""
render.py — builds one 400x300 1-bit frame for the Waveshare 4.2" V2 e-paper
panel, showing Japan's prefecture outlines, station activity, and the most
recent JMA-relayed earthquake event.

No browser, no HTML/JS involved — this draws directly with Pillow, which is
the right approach for a Pi Zero: SPI panels only accept a raw pixel buffer,
and Chromium-class rendering is impractical on that hardware anyway.
"""

import json
import math
import os
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from PIL import Image, ImageDraw, ImageFont

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
FONT_PATH = os.path.join(BASE_DIR, "fonts", "NotoSansJP-Bold.ttf")
# Noto Sans JP, pre-instanced to a static bold weight and subset down to
# JIS X 0208 levels 1+2 (~6,600 glyphs) instead of shipping the full ~9.5MB
# variable font with every CJK ideograph. Two separate wins on a Pi Zero:
# no per-render variable-font interpolation, and a much smaller file to
# read off a slow SD card. See fonts/README.md for how this was built and
# how to regenerate it if you ever hit a genuinely missing glyph.

W, H = 400, 300                     # Waveshare 4.2" V2 native resolution
MAP_BOX = (4, 4, 396, 296)          # full canvas, small margin — no side column anymore
INFO_BOX = (4, 4, 180)               # x0, y0, x1 — height is computed from actual content now
BOUNDS = (30.7, 45.8, 128.6, 146.2)  # lat0, lat1, lon0, lon1 — same frame as the web version

API_URL = "https://api.p2pquake.net/v2/history?codes=551&limit=8"

# The live feed reports prefecture names in Japanese (熊本県, 広島県...);
# stations.json and labels.json key off the short English names used
# throughout this project (Kumamoto, Hiroshima...). Without this mapping,
# matching silently fails and nothing highlights, ever.
PREF_JA_TO_EN = {
    "北海道": "Hokkaido", "青森県": "Aomori", "岩手県": "Iwate", "宮城県": "Miyagi",
    "秋田県": "Akita", "山形県": "Yamagata", "福島県": "Fukushima", "茨城県": "Ibaraki",
    "栃木県": "Tochigi", "群馬県": "Gunma", "埼玉県": "Saitama", "千葉県": "Chiba",
    "東京都": "Tokyo", "神奈川県": "Kanagawa", "新潟県": "Niigata", "富山県": "Toyama",
    "石川県": "Ishikawa", "福井県": "Fukui", "山梨県": "Yamanashi", "長野県": "Nagano",
    "岐阜県": "Gifu", "静岡県": "Shizuoka", "愛知県": "Aichi", "三重県": "Mie",
    "滋賀県": "Shiga", "京都府": "Kyoto", "大阪府": "Osaka", "兵庫県": "Hyogo",
    "奈良県": "Nara", "和歌山県": "Wakayama", "鳥取県": "Tottori", "島根県": "Shimane",
    "岡山県": "Okayama", "広島県": "Hiroshima", "山口県": "Yamaguchi", "徳島県": "Tokushima",
    "香川県": "Kagawa", "愛媛県": "Ehime", "高知県": "Kochi", "福岡県": "Fukuoka",
    "佐賀県": "Saga", "長崎県": "Nagasaki", "熊本県": "Kumamoto", "大分県": "Oita",
    "宮崎県": "Miyazaki", "鹿児島県": "Kagoshima", "沖縄県": "Okinawa",
}

# Short Japanese names (no 県/府/都/道 suffix, except Hokkaido which has none
# to drop) for on-map labels — noticeably more compact than the English
# romanization, which is what makes labeling all 46 at once feasible here.
EN_TO_JA_SHORT = {
    "Hokkaido": "北海道", "Aomori": "青森", "Iwate": "岩手", "Miyagi": "宮城",
    "Akita": "秋田", "Yamagata": "山形", "Fukushima": "福島", "Ibaraki": "茨城",
    "Tochigi": "栃木", "Gunma": "群馬", "Saitama": "埼玉", "Chiba": "千葉",
    "Tokyo": "東京", "Kanagawa": "神奈川", "Niigata": "新潟", "Toyama": "富山",
    "Ishikawa": "石川", "Fukui": "福井", "Yamanashi": "山梨", "Nagano": "長野",
    "Gifu": "岐阜", "Shizuoka": "静岡", "Aichi": "愛知", "Mie": "三重",
    "Shiga": "滋賀", "Kyoto": "京都", "Osaka": "大阪", "Hyogo": "兵庫",
    "Nara": "奈良", "Wakayama": "和歌山", "Tottori": "鳥取", "Shimane": "島根",
    "Okayama": "岡山", "Hiroshima": "広島", "Yamaguchi": "山口", "Tokushima": "徳島",
    "Kagawa": "香川", "Ehime": "愛媛", "Kochi": "高知", "Fukuoka": "福岡",
    "Saga": "佐賀", "Nagasaki": "長崎", "Kumamoto": "熊本", "Oita": "大分",
    "Miyazaki": "宮崎", "Kagoshima": "鹿児島",
}


# ---------- data loading (all cached at module level — loaded once per
# process, not once per frame, since main.py calls build_frame() repeatedly
# for the life of the program) ----------

_cache = {}


def load_json(name):
    if name not in _cache:
        with open(os.path.join(DATA_DIR, name), encoding="utf-8") as f:
            _cache[name] = json.load(f)
    return _cache[name]


def load_fonts():
    if "fonts" not in _cache:
        _cache["fonts"] = {
            "h1": ImageFont.truetype(FONT_PATH, 17),
            "body": ImageFont.truetype(FONT_PATH, 14),
            "small": ImageFont.truetype(FONT_PATH, 11),
            "tiny": ImageFont.truetype(FONT_PATH, 10),
            "micro": ImageFont.truetype(FONT_PATH, 9),
        }
    return _cache["fonts"]


def get_projector():
    if "projector" not in _cache:
        _cache["projector"] = make_projector(BOUNDS, MAP_BOX)
    return _cache["projector"]


# ---------- projection ----------

def make_projector(bounds, box):
    lat0, lat1, lon0, lon1 = bounds
    x0, y0, x1, y1 = box
    lat_mid = (lat0 + lat1) / 2
    cosf = math.cos(math.radians(lat_mid))
    world_w = (lon1 - lon0) * cosf
    world_h = lat1 - lat0
    avail_w, avail_h = x1 - x0, y1 - y0
    scale = min(avail_w / world_w, avail_h / world_h)
    off_x = x0 + (avail_w - world_w * scale) / 2
    off_y = y0 + (avail_h - world_h * scale) / 2

    def project(lat, lon):
        px = off_x + (lon - lon0) * cosf * scale
        py = off_y + (lat1 - lat) * scale
        return px, py

    return project


# ---------- drawing ----------

def draw_prefectures(draw, geojson, project):
    for feature in geojson["features"]:
        if feature["properties"]["nam"] == "Okinawa Ken":
            continue  # out of frame, same as the web version
        geom = feature["geometry"]
        polys = geom["coordinates"] if geom["type"] == "MultiPolygon" else [geom["coordinates"]]
        for poly in polys:
            for ring in poly:
                pts = [project(lat, lon) for lon, lat in ring]
                draw.line(pts + [pts[0]], fill=0, width=1)


def draw_stations(draw, stations, project):
    cs = 2  # every station gets a small fixed-size X, marking its location only
    for name, pref, lat, lon in stations:
        x, y = project(lat, lon)
        draw.line([(x - cs, y - cs), (x + cs, y + cs)], fill=0)
        draw.line([(x - cs, y + cs), (x + cs, y - cs)], fill=0)


def ripple_count_from_scale(code):
    return max(1, math.ceil(code / 10))  # shindo 1 -> 1 ring, shindo 7 -> 7 rings


def draw_shindo_ripples(draw, project, epicenter_lat, epicenter_lon, max_scale, active_points):
    """One ring per shindo point, like ripples from where the quake actually
    happened — not one circle per station. The outer ring's radius reflects
    how far the felt area actually reached: the farthest affected
    prefecture from the epicenter, not a fixed size."""
    ex, ey = project(epicenter_lat, epicenter_lon)
    outer_r = 10.0
    for lat, lon in active_points:
        px, py = project(lat, lon)
        outer_r = max(outer_r, math.hypot(px - ex, py - ey))

    n = ripple_count_from_scale(max_scale)
    for i in range(1, n + 1):
        r = outer_r * i / n
        draw.ellipse([ex - r, ey - r, ex + r, ey + r], outline=0, width=1)
    draw.ellipse([ex - 2, ey - 2, ex + 2, ey + 2], fill=0)  # epicenter itself


LEFT_COL_X = 66          # left column: text ends here, grows further left into the margin
RIGHT_COL_X = W - 66     # right column: text starts here, grows further right into the margin
LEFT_COL_Y_BOTTOM = 292          # left column's bottom bound; its top depends on the info box's actual height
RIGHT_COL_Y_RANGE = (8, 260)    # right column now stops short, handing its bottom off to the row below
BOTTOM_ROW_Y = 286              # a third margin: the empty strip along the very bottom edge
BOTTOM_ROW_X_RANGE = (100, 328)  # between the two columns, clear of both


def pack_1d(natural_positions, y0, y1, min_gap):
    """Start from each label's actual (clamped) position, sorted, and only
    push apart the ones that would otherwise overlap — by the minimum
    needed, not by stretching everything across the full range. Two nearby
    prefectures stay visually near each other; a genuinely crowded cluster
    still spreads out because it has to."""
    n = len(natural_positions)
    if n == 0:
        return []
    pos = [min(max(p, y0), y1) for p in natural_positions]

    # forward pass: push later items down if they're too close to the one before
    for i in range(1, n):
        if pos[i] - pos[i - 1] < min_gap:
            pos[i] = pos[i - 1] + min_gap

    # if that pushed the last item past the bottom, pull the whole chain
    # back up from the end instead, so it still respects the bounds
    if pos[-1] > y1:
        pos[-1] = y1
        for i in range(n - 2, -1, -1):
            if pos[i + 1] - pos[i] < min_gap:
                pos[i] = pos[i + 1] - min_gap

    return pos


def draw_prefecture_labels(draw, fonts, labels, project, active_prefs, left_y_range):
    """Only the prefecture(s) the current event actually affects get a
    label — same as the original design, just with the Japanese short name
    (北海道, 熊本, ...) instead of the English romanization, since Japanese
    takes less space. Still placed in the margins (below the status box,
    the right side, and along the bottom) rather than hugging the
    coastline, since that's what avoided landing on top of the map."""
    font = fonts["micro"]
    pts = []
    for name, clat, clon, _llat, _llon in labels:
        if name not in active_prefs:
            continue
        p = project(clat, clon)
        pts.append({"text": EN_TO_JA_SHORT.get(name, name), "p": p})

    left = sorted([it for it in pts if it["p"][0] < W / 2], key=lambda it: it["p"][1])
    right = sorted([it for it in pts if it["p"][0] >= W / 2], key=lambda it: it["p"][1])

    # The left column's height depends on how tall the info box ended up
    # (a short recent-log gives it more room) — a plain geographic split
    # can still leave more in the left column than fits. Rebalance by
    # capacity: move the left entries sitting closest to the midline (the
    # weakest "left" calls) over to the right column.
    min_spacing = 10
    left_capacity = max(1, int((left_y_range[1] - left_y_range[0]) / min_spacing))
    if len(left) > left_capacity:
        left.sort(key=lambda it: -it["p"][0])  # closest to the midline first
        overflow = left[:len(left) - left_capacity]
        left = left[len(left) - left_capacity:]
        right = sorted(right + overflow, key=lambda it: it["p"][1])
    left.sort(key=lambda it: it["p"][1])

    # The right column is still the most crowded of the two. Peel its
    # southernmost entries off into a third pool along the bottom edge —
    # they're already near the bottom of the map, so this is a short,
    # natural-looking leader line rather than a long detour.
    bottom_capacity = 8
    right.sort(key=lambda it: it["p"][1])
    bottom = right[-bottom_capacity:] if len(right) > bottom_capacity else []
    right = right[:-bottom_capacity] if bottom else right
    bottom.sort(key=lambda it: it["p"][0])

    def place(items, col_x, y_range, side):
        y0, y1 = y_range
        positions = pack_1d([it["p"][1] for it in items], y0, y1, min_gap=13)
        for it, ly in zip(items, positions):
            elbow_x = col_x + 14 if side == "left" else col_x - 14
            p = it["p"]
            draw.line([(col_x, ly), (elbow_x, ly), p], fill=0, width=1)
            anchor = "rm" if side == "left" else "lm"
            draw.text((col_x, ly), it["text"], font=font, fill=0, anchor=anchor)

    place(left, LEFT_COL_X, left_y_range, "left")
    place(right, RIGHT_COL_X, RIGHT_COL_Y_RANGE, "right")

    x0, x1 = BOTTOM_ROW_X_RANGE
    positions = pack_1d([it["p"][0] for it in bottom], x0, x1, min_gap=32)
    for it, lx in zip(bottom, positions):
        p = it["p"]
        elbow_y = BOTTOM_ROW_Y - 10
        draw.line([(lx, BOTTOM_ROW_Y), (lx, elbow_y), p], fill=0, width=1)
        draw.text((lx, BOTTOM_ROW_Y), it["text"], font=font, fill=0, anchor="ma")


def format_time(t):
    """JMA's origin time is only ever precise to the minute — every real
    timestamp this feed has ever returned ends in ':00'. Displaying
    seconds that never carry information just costs width for nothing."""
    if not t:
        return t
    return t.rsplit(":", 1)[0]


def wrap_cjk(text, max_chars):
    return [text[i:i + max_chars] for i in range(0, len(text), max_chars)] or [text]


def scale_label(code):
    table = [(70, "7"), (60, "6+"), (55, "6-"), (50, "5+"), (45, "5-"),
             (40, "4"), (30, "3"), (20, "2"), (10, "1")]
    for th, lab in table:
        if code >= th:
            return lab
    return "0"


def compute_info_box_height(events, pad=6):
    """How tall the info box actually needs to be for this event — no
    reason to reserve fixed space for a 3rd recent-log line when there are
    only one or two to show."""
    if not events:
        return pad * 2 + 16

    latest = events[0]
    region = latest["earthquake"]["hypocenter"]["name"] or "Unknown"
    n_region_lines = len(wrap_cjk(region, 11)[:2])
    n_recent = len(events[1:3])

    h = pad  # top padding
    h += n_region_lines * 18
    h += 16   # mag/shindo/depth line
    h += 15   # time line
    if n_recent:
        h += 4    # gap before divider
        h += n_recent * 13
    h += pad  # bottom padding
    return h


def draw_info_box(draw, fonts, events, box):
    x0, y0, x1 = box
    y1 = y0 + compute_info_box_height(events)
    # clear whatever map content sits under the box, then frame it, so the
    # status readout is always legible regardless of what's underneath
    draw.rectangle([x0, y0, x1, y1], fill=1, outline=None)
    draw.rectangle([x0, y0, x1, y1], outline=0, width=1)

    pad = 6
    x, y = x0 + pad, y0 + pad
    right = x1 - pad

    if not events:
        draw.text((x, y), "No data", font=fonts["body"], fill=0)
        return y1

    latest = events[0]
    eq = latest["earthquake"]
    region = eq["hypocenter"]["name"] or "Unknown"
    for line in wrap_cjk(region, 11)[:2]:
        draw.text((x, y), line, font=fonts["body"], fill=0)
        y += 18

    mag = eq["hypocenter"].get("magnitude")
    depth = eq["hypocenter"].get("depth")
    scale = scale_label(eq.get("maxScale", 0))
    mag_s = f"M{mag:.1f}" if mag is not None else "M—"
    depth_s = f"{depth}km" if depth is not None else "—"
    draw.text((x, y), f"{mag_s}  Shindo {scale}  {depth_s}", font=fonts["small"], fill=0)
    y += 16

    draw.text((x, y), format_time(eq.get("time", "")), font=fonts["tiny"], fill=0)
    y += 15

    recent = events[1:3]
    if recent:
        draw.line([(x, y), (right, y)], fill=0, width=1)
        y += 4
        for ev in recent:
            e = ev["earthquake"]
            name = (e["hypocenter"]["name"] or "?")[:10]
            s = scale_label(e.get("maxScale", 0))
            draw.text((x, y), f"{name} S{s}", font=fonts["tiny"], fill=0)
            y += 13

    return y1


def get_label_centroid():
    if "label_centroid" not in _cache:
        labels = load_json("labels.json")
        _cache["label_centroid"] = {name: (clat, clon) for name, clat, clon, _l, _o in labels}
    return _cache["label_centroid"]


def get_base_map():
    """Prefecture outlines and station markers never change between frames —
    render them once and reuse a copy, instead of redrawing several thousand
    line segments from the geojson on every single event."""
    if "base_map" not in _cache:
        img = Image.new("1", (W, H), 1)
        draw = ImageDraw.Draw(img)
        project = get_projector()
        draw_prefectures(draw, load_json("prefectures.geojson"), project)
        draw_stations(draw, load_json("stations.json"), project)
        _cache["base_map"] = img
    return _cache["base_map"].copy()


# ---------- top-level build ----------

def build_frame(events):
    """events: list from the p2pquake /history?codes=551 response, newest first."""
    img = get_base_map()
    draw = ImageDraw.Draw(img)
    fonts = load_fonts()

    labels = load_json("labels.json")
    project = get_projector()

    label_centroid = get_label_centroid()

    active_prefs = set()
    lat = lon = None
    max_scale = 0
    if events:
        latest = events[0]
        eq = latest["earthquake"]
        lat, lon = eq["hypocenter"].get("latitude"), eq["hypocenter"].get("longitude")
        max_scale = eq.get("maxScale", 0) or 0
        for pt in latest.get("points") or []:
            pref_ja = pt.get("pref")
            if not pref_ja:
                continue
            pref_en = PREF_JA_TO_EN.get(pref_ja)
            if not pref_en:
                continue  # unrecognized pref string — skip rather than mismatch silently
            active_prefs.add(pref_en)

    # The info box is only as tall as it needs to be (see
    # compute_info_box_height) — the left label column starts right below
    # wherever that actually ends up, reclaiming whatever space a short
    # recent-log freed rather than leaving it blank.
    info_box_bottom = INFO_BOX[1] + compute_info_box_height(events)
    left_y_range = (info_box_bottom + 8, LEFT_COL_Y_BOTTOM)

    draw_prefecture_labels(draw, fonts, labels, project, active_prefs, left_y_range)
    if lat is not None and lon is not None and max_scale > 0:
        active_points = [label_centroid[p] for p in active_prefs if p in label_centroid]
        draw_shindo_ripples(draw, project, lat, lon, max_scale, active_points)

    draw_info_box(draw, fonts, events, INFO_BOX)

    return img


def _make_session():
    """A pooled, retrying session — reused across the process's lifetime so
    we're not paying a fresh TCP+TLS handshake (real CPU cost on this
    hardware) for every single fetch, and so transient network blips (a
    dropped packet, a momentary DNS hiccup) resolve themselves without
    every caller needing its own retry logic."""
    session = requests.Session()
    retry = Retry(
        total=3, connect=3, read=3,
        backoff_factor=1.5,  # ~1.5s, 3s, 6s between attempts
        status_forcelist=[500, 502, 503, 504],
        allowed_methods=["GET"],
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    session.mount("http://", adapter)
    return session


_session = _make_session()


def fetch_events():
    resp = _session.get(API_URL, timeout=15)
    resp.raise_for_status()
    return resp.json()


if __name__ == "__main__":
    # standalone test: renders a PNG you can inspect without any e-paper hardware
    evs = fetch_events()
    frame = build_frame(evs)
    frame.save(os.path.join(BASE_DIR, "preview.png"))
    print("wrote preview.png")
